#include <stdio.h>

FILE *open_file_in_dir(char *filename, char *dirname);