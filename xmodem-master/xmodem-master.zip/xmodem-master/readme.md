Original code from:
https://www.menie.org/georges/embedded/xmodem.html
